import json
import sys
from pathlib import Path


# ============================================================
# 프로젝트 경로
# ============================================================

ROOT_DIR = (
    Path(__file__)
    .resolve()
    .parents[1]
)

SRC_DIR = (
    ROOT_DIR
    / "src"
)

sys.path.insert(
    0,
    str(SRC_DIR),
)


from peerproof.profile import (
    ProfileEvidenceExtractor,
)


PROCESSED_ROOT = (
    ROOT_DIR
    / "data"
    / "processed"
)


# ============================================================
# JSON
# ============================================================

def load_json(
    path: Path,
):

    if not path.exists():
        return {}

    with open(
        path,
        "r",
        encoding="utf-8",
    ) as file:

        return json.load(
            file
        )


def save_json(
    path: Path,
    data,
):

    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    with open(
        path,
        "w",
        encoding="utf-8",
    ) as file:

        json.dump(
            data,
            file,
            ensure_ascii=False,
            indent=2,
        )


# ============================================================
# 출력용
# ============================================================

def print_category_summary(
    category: str,
    data: dict,
):

    evidence = data.get(
        "evidence",
        [],
    )

    text_count = sum(
        1
        for item in evidence
        if item[
            "type"
        ] == "text"
    )

    table_count = sum(
        1
        for item in evidence
        if item[
            "type"
        ] == "table"
    )

    print(
        f"{category:<10}"
        f"총 {len(evidence):>3}개 "
        f"(문단 {text_count}, "
        f"표 {table_count})"
    )


# ============================================================
# main
# ============================================================

def main():

    print()
    print(
        "=" * 70
    )

    print(
        "PEERPROOF / "
        "BUSINESS PROFILE EVIDENCE BUILDER"
    )

    print(
        "=" * 70
    )

    company_name = input(
        "\n기업명을 입력하세요: "
    ).strip()

    if not company_name:

        print(
            "기업명을 입력해야 합니다."
        )

        return

    company_dir = (
        PROCESSED_ROOT
        / company_name
    )

    if not company_dir.exists():

        print()
        print(
            "전처리 데이터가 없습니다."
        )

        print(
            company_dir
        )

        return

    # --------------------------------------------------------
    # metadata
    # --------------------------------------------------------

    metadata_path = (
        company_dir
        / "processed_metadata.json"
    )

    processed_metadata = (
        load_json(
            metadata_path
        )
    )

    company_metadata = (
        processed_metadata.get(
            "company",
            {}
        )
    )

    # --------------------------------------------------------
    # extractor
    # --------------------------------------------------------

    print()
    print(
        "[1/2] Business Profile "
        "관련 근거 추출"
    )

    extractor = (
        ProfileEvidenceExtractor(
            company_dir
        )
    )

    profile_evidence = (
        extractor.build(
            company_metadata=(
                company_metadata
            )
        )
    )

    # --------------------------------------------------------
    # 저장
    # --------------------------------------------------------

    profile_dir = (
        company_dir
        / "profile"
    )

    output_path = (
        profile_dir
        / "profile_evidence.json"
    )

    save_json(
        output_path,
        profile_evidence,
    )

    # --------------------------------------------------------
    # 요약 출력
    # --------------------------------------------------------

    print()
    print(
        "[2/2] 추출 결과"
    )

    print()

    categories = (
        profile_evidence[
            "categories"
        ]
    )

    for category in (
        "business",
        "growth",
        "risk",
        "finance",
    ):

        print_category_summary(
            category,
            categories[
                category
            ],
        )

    print()
    print(
        "=" * 70
    )

    print(
        "Business Profile 근거 추출 완료"
    )

    print(
        "=" * 70
    )

    print()
    print(
        "저장:"
    )

    print(
        output_path
    )

    print()
    print(
        "다음 단계:"
    )

    print(
        "profile_evidence.json "
        "→ 실제 company_profile.json 구조화"
    )


if __name__ == "__main__":
    main()